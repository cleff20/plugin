<?php
/**
 * @package WPSEO\Admin
 */

/**
 * Class WPSEO_GSC_Config
 */
class WPSEO_GSC_Config {

	/**
	 * @var array
	 */
	public static $gsc = array(
		'application_name' => 'Yoast SEO',
		'client_id'        => '395430892738-ushj8aced0cji2j4bkq6bda6felaigb9.apps.googleusercontent.com',
		'client_secret'    => 'c2kYgOwMhk1emWxQ3NaA8wOi',
		'redirect_uri'     => 'urn:ietf:wg:oauth:2.0:oob',
		'scopes'           => array( 'https://www.googleapis.com/auth/webmasters' ),
	);

}
